module.exports = app => {
    let router = require("express").Router();

    app.use('/peliculas', router);
};